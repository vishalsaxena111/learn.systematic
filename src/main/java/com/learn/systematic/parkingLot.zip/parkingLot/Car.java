package com.learn.systematic.parkingLot;

public class Car extends Vehicle{

    Car(String number){
        this.number = number;
    }

}
