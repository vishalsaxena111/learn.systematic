package com.learn.systematic.parkingLot;

public class Bike extends Vehicle{

        Bike(String number){
            this.number = number;
        }

}
