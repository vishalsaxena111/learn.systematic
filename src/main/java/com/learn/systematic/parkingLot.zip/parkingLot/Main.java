package com.learn.systematic.parkingLot;

import java.util.Arrays;
import java.util.List;

public class Main {
    public static void main(String[] args) {

        List<Floor> floors = Arrays.asList(new Floor(1,2),
                new Floor(2,2));
        ParkingLot parkingLot = ParkingLot.getInstance(floors);


        Vehicle v1 = new Bike("UP 1234");
        System.out.println("Vehicle inserted "+ v1.number);
        parkingLot.insertVehicle(v1);



        Vehicle v2 = new Truck("UP 2345");
        Vehicle V3 = new Bike("UP 3456");

    }
}
