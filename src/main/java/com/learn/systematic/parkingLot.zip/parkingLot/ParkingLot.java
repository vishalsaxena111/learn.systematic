package com.learn.systematic.parkingLot;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

public class ParkingLot {

    private static ParkingLot INSTANCE;

    private List<Floor> floorList;

   private ParkingLot(){}

    public static ParkingLot getInstance(List<Floor> floorList){

       if(INSTANCE==null) {
           INSTANCE = new ParkingLot();
           INSTANCE.floorList = floorList;
       }

        System.out.println("ParkingLot created with "+ floorList.size() +" floors");

       return INSTANCE;

    }

    public void insertVehicle(Vehicle v){

       Spot spot = new Spot(false);
       spot.setEntryTime(LocalDateTime.now());
        System.out.println(this.floorList.size());

        this.floorList.get(0).spotList.add(spot);

        System.out.println("spot occupied for vehicle "+v.number);

    }

}
