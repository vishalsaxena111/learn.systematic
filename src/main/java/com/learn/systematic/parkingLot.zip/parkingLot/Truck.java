package com.learn.systematic.parkingLot;

public class Truck extends Vehicle{

    Truck(String number){
        this.number = number;
    }


}
