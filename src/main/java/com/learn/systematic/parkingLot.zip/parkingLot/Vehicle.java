package com.learn.systematic.parkingLot;

public abstract class Vehicle {

    public String number;

}
