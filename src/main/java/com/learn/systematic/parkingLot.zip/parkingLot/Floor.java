package com.learn.systematic.parkingLot;

import java.util.ArrayList;
import java.util.List;

public class Floor {

    private int floorNumber;
    private int capacity;

    public List<Spot> spotList = new ArrayList<>();

    public int getFloorNumber() {
        return floorNumber;
    }

    public void setFloorNumber(int floorNumber) {
        this.floorNumber = floorNumber;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public Floor(int floorNumber, int capacity) {
        this.floorNumber = floorNumber;
        this.capacity = capacity;
    }


}
